# Comparison review: 319b14d236efb259f79a695b1020144caa0ee2c7...HEAD

Target: 319b14d236efb259f79a695b1020144caa0ee2c7...HEAD.

Reviewers: claude-code claude-opus-5-5 / CLI2.1.310; codex GPT-6 Codex agent runtime \(native CLI companion unavailable\); Melian's own review, in 3 stored rounds.

Adjudication records valid, noise, or duplicate, with severity and a miss reason where required. Pending findings await the maintainer.

## A. claude-code claude-opus-5-5 / CLI2.1.310, round range-10a17438c2ea67d2.r1

6 findings at fd68b824c82f.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| A1 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/cli/src/compare.ts:264-269 | Stats counts a round as unattributed even when another pull request's snapshot holds it as a member: \`comparisonStats\` takes the union of every pull request's current \`unattributed\` round IDs. A round is unattributed only relative to one pull request: it sits in a store that holds that pull request's member, at a head that pull request does not name. The same round can be a numbered member of anoth… | noise, P3 | none |
| A2 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/cli/src/pull-request-comparison.ts:63-64 | A bare membership read with nothing to accept fails without a git author: \`refresh\` always calls \`gitAuthor\(..., "accepted pull request membership"\)\`, even when \`accept\` is false and nothing is rejected. A bare \`melian compare "\#N"\`, the command that now replaces the default import, therefore exits 1 in a clone with no git identity. The message talks about accepting membe… | valid, P3, owned-missed | correctness |
| A3 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/cli/src/pull-request-comparison.ts:97-101 | Pull-request export drops the PR storage's unattributed comparisons once a snapshot exists: After the first membership snapshot, \`export\` keeps only entries whose \`round\` is a current member: \`entry.round \!== undefined &amp;&amp; ids.has\(entry.round\)\`. Version-1 comparisons that migration could not attribute come back from \`ComparisonReader\` with \`unattributed: &lt;revision key&gt;\` and no \`round\`, so t… | valid, P2 | none |
| A4 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/core/src/pull-request-rounds.ts:103-116 | An unfetchable pull-request base is recorded as every member's own missing commit: \`classify\` checks \`\[candidate.head, candidate.base, this.base\]\` for every range candidate. When the pull request's own base \(\`this.base\`, GitHub's \`baseRefOid\`\) is absent and the fetch fails, the code reports it as the candidate's \`missingCommit\`. \`PullRequestRoundHistory.refresh\` then treats any ea… | valid, P3, owned-missed | correctness |
| A5 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/pipeline/src/compare.ts:282-283 | close\(\) lost its TSDoc, which now sits stacked above refreshMembership: The new method was inserted between \`close\(\)\` and its doc comment. \`refreshMembership\` now carries two doc comments, and the first, which tooling attaches, reads 'Closes the harness and its storage. Idempotent.'. \`close\(\)\`, which is exported package API, has none. AGENTS.md requires TSDoc on exporte… | valid, P3, owned-missed | conventions |
| A6 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/pipeline/src/pull-request-rounds.ts:111-117 | Every other pull request's rounds in the clone enter each snapshot's foreign set: The scan classifies every round in every storage in the state directory. A pull-request-provenance round of another pull request returns \`foreign\` \('stored ownership names another pull request'\). The snapshot then keeps every \`foreign\` candidate with its full fields, and the command prints each as a… | noise, P3 | none |

## B. codex GPT-6 Codex agent runtime \(native CLI companion unavailable\), round range-10a17438c2ea67d2.r1

0 findings at fd68b824c82f.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|

## C. Melian review, round range-10a17438c2ea67d2.r1

6 findings at fd68b824c82f, verdict findings.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| C1 | Melian, lens.design | packages/cli/src/pull-request-comparison.ts:97-101 | contradicts-documented-decision: Once a membership snapshot exists, \`PullRequestComparison.export\` keeps only entries whose \`round\` is a snapshot member \(\`entry.round \!== undefined &amp;&amp; ids.has\(entry.round\)\`\). \`ComparisonReader\` returns the version-1 comparisons it could not attribute with \`round\` undefined and \`unattributed: &lt;revisi… | valid, P2 | none |
| C2 | Melian, guardrails | docs/design/comparison-with-external-reviewers.md:57 | guardrail/forbidden-patterns: This line matches the forbidden-patterns rule overlong-sentence. | valid, P3 | none |
| C3 | Melian, lens.conventions | packages/cli/src/comparison-stores.ts:14 | quoted-rule-violation: \`ComparisonStores\` has a TSDoc comment, but it is internal to the CLI. \`packages/cli/src/index.ts\` does not export it. This is one of two instances in this change; the other is the \`PullRequestComparison\` class doc at packages/cli/src/pull-request-comparison.ts:17. | valid, P3 | none |
| C4 | Melian, lens.conventions | packages/cli/src/pull-request-comparison.ts:17 | quoted-rule-violation: \`PullRequestComparison\` has a TSDoc comment, but it is internal to the CLI. \`packages/cli/src/index.ts\` does not export it. This is one of two instances in this change; the other is \`ComparisonStores\` at packages/cli/src/comparison-stores.ts:14. | valid, P3 | none |
| C5 | Melian, static.enola | packages/github/src/rounds.ts:71 | enola/performance: Performance risk \(compounded, O\(n³\)\): packages/github/src.PullRequestRoundsReader.read | valid, P3 | none |
| C6 | Melian, static.enola | packages/pipeline/src/pull-request-rounds.ts:60 | enola/complexity-outliers: High cyclomatic complexity: packages/pipeline/src.PullRequestRoundHistory.refresh \(50\) | valid, P3 | none |

## D. claude-code claude-opus-5-5 / CLI2.1.310, round range-10a17438c2ea67d2.r2

1 finding at 42cef9eb6171.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| D1 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/cli/src/pull-request-comparison.ts:114-118 | Post-snapshot JSON export re-serialises the escaped record and emits raw bidi and C1 controls from reviewer text: Once a membership snapshot exists, \`PullRequestComparison.export\` builds JSON as \`JSON.stringify\({ ...JSON.parse\(record\), membership, history }, null, 2\)\`, where \`record\` is \`ComparisonExport.renderJson\(\)\`. renderJson runs \`visibleText\` over each output line, so U+007F-U+009F, U+2028/U+2029, U+061C,… | valid, P2, owned-missed | trust-boundary |

## E. codex GPT-6 Codex agent runtime \(native CLI companion unavailable\), round range-10a17438c2ea67d2.r2

0 findings at 42cef9eb6171.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|

## F. Melian review, round range-10a17438c2ea67d2.r2

2 findings at 42cef9eb6171, verdict findings.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| F1 | Melian, static.enola | packages/github/src/rounds.ts:71 | enola/performance: Performance risk \(compounded, O\(n³\)\): packages/github/src.PullRequestRoundsReader.read | valid, P3 | none |
| F2 | Melian, static.enola | packages/pipeline/src/pull-request-rounds.ts:60 | enola/complexity-outliers: High cyclomatic complexity: packages/pipeline/src.PullRequestRoundHistory.refresh \(50\) | valid, P3 | none |

## G. claude-code claude-opus-5-5 / CLI2.1.310, round range-10a17438c2ea67d2.r3

1 finding at b6d4e8c2e161.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| G1 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/cli/src/pull-request-comparison.ts:97-102 | After any membership snapshot, export silently drops the pull request's own comparisons from rounds minted later: \`PullRequestComparison.export\` filters attributed entries with \`entry.round \!== undefined &amp;&amp; ids.has\(entry.round\)\`, where \`ids\` holds the members of the saved snapshot. The filter applies to the pull request's own \`pull-&lt;hash&gt;.sqlite\` too. Rounds there carry pull-request provenance, so the rounds de… | valid, P2, owned-missed | design |

## H. codex GPT-6 Codex agent runtime \(native CLI companion unavailable\), round range-10a17438c2ea67d2.r3

0 findings at b6d4e8c2e161.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|

## I. Melian review, round range-10a17438c2ea67d2.r3

3 findings at b6d4e8c2e161, verdict findings.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| I1 | Melian, static.enola | packages/github/src/rounds.ts:71 | enola/performance: Performance risk \(compounded, O\(n³\)\): packages/github/src.PullRequestRoundsReader.read | valid, P3 | none |
| I2 | Melian, static.enola | packages/pipeline/src/pull-request-rounds.ts:60 | enola/complexity-outliers: High cyclomatic complexity: packages/pipeline/src.PullRequestRoundHistory.refresh \(50\) | valid, P3 | none |
| I3 | Melian, lens.conventions | packages/pipeline/test/pull-request-schema.test.ts:4 | quoted-rule-violation: The test loads \`../src/pull-request-rounds.ts\` with \`await import\(\)\` and never calls \`vi.resetModules\(\)\` first. | valid, P3 | none |

## Maintainer decisions

- Unattributed membership is relative to each PR. The report proposes a different global unknown-round metric; subtracting all other PR members is not the current contract. Aggregate metric design remains deferred. From 0f451bc9fff91302 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:39.263Z).
- Confirmed migrated unattributed comparison export loss; independently matched Claude C1. Fix preserves own/member-store records and refuses JSON cross-store legacy-key collisions before writing output. From 2240c811cfd82c0e at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:42.531Z).
- Confirmed data loss of genuine migrated legacy comparisons after the first membership read. Fixed by preserving raw entries from the own pull and member-holding stores. From 2be3ed6ea18dd693 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:35.965Z).
- Accepted internal TSDoc advisory; removed the internal ComparisonStores class comment. From 34ea6c05ef73e2fa at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:44.519Z).
- Confirmed exported close\(\) API documentation attached above refreshMembership instead. Fixed by moving it above close\(\); conventions owns the missed TSDoc rule. From 5b7847c7980c927d at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:40.387Z).
- Accepted static performance advisory. Complete pagination and explicit 250-commit refusal bound this path; no measured regression requires a redesign in this build. From 5b874eb3710885af at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:46.676Z).
- Accepted internal TSDoc advisory; removed the internal PullRequestComparison class comment. From 791d6934d88cc273 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:45.578Z).
- Reproduced ordinary bare membership reads failing without a Git identity. Only acceptance needs an audit author. Fixed by resolving the author only with --accept. From b1bf678a4569bf1e at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:41.554Z).
- Accepted writing advisory; split the long rounds documentation sentence in the fix batch. From bef6530d4b49c3a9 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:43.527Z).
- Accepted availability and diagnostic limitation: a missing current PR base affects range attribution and may label prior members unreachable. Ownership-first attribution must remain possible without that base; an unconditional open-time gate is unsuitable. Data and prior ownership survive. Advisory retained without changing the missing-commit policy in this batch. From c2eb5b511c708184 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:37.118Z).
- Accepted complexity advisory. The membership refresh implements the explicit ownership, reachability and acceptance cases; no additional mechanism added for this advisory. From e70e25181cfdec99 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:47.677Z).
- The active first-ownership rule classifies rounds owned by another PR as foreign. The all-store scan and explicit foreign reasons are intentional; pruning them requires a new display policy. From eac842d89b975ae6 at fd68b824c82f, by Tal Rotbart (2026-10-27T03:49:38.227Z).
- Confirmed offline with genuine legacy state: post-snapshot parse/re-serialisation reverses safe JSON Unicode escapes in external reviewer text. Restoring the existing final-output escaping contract. Core visibleText must be applied after the last JSON serialisation; no raw control bytes on stdout or file output. From 2ea487afb7d97ae1 at 42cef9eb6171, by Tal Rotbart (2026-10-27T04:29:42.134Z).
- Accepted static performance advisory. Complete pagination and the explicit 250-commit refusal bound this reader; no measured regression requires a redesign. From 5b874eb3710885af at 42cef9eb6171, by Tal Rotbart (2026-10-27T04:17:41.697Z).
- Accepted membership refresh complexity advisory. The explicit ownership, reachability and acceptance cases remain covered by audited manual proof and regression tests. From e70e25181cfdec99 at 42cef9eb6171, by Tal Rotbart (2026-10-27T04:17:42.601Z).
- Confirmed real review/import/snapshot/new-review/import/adjudication flow silently omits the newer own-store comparison. Same data-selection class as R1: stored ownership is authoritative, while a cached snapshot may predate records. A shared pure tri-state ownership query will govern classify and offline export; cached member conflicts refuse before output, with no fabricated snapshot or numbering. From 15743af4e9678ee8 at b6d4e8c2e161, by Tal Rotbart (2026-10-27T05:43:19.361Z).
- Accepted static performance advisory; complete pagination and explicit 250-commit refusal bound this reader, with no measured regression requiring redesign. From 5b874eb3710885af at b6d4e8c2e161, by Tal Rotbart (2026-10-27T05:08:43.651Z).
- Accepted refresh complexity advisory; audited ownership, reachability and acceptance cases remain explicit and covered by generated/manual proof. From e70e25181cfdec99 at b6d4e8c2e161, by Tal Rotbart (2026-10-27T05:08:44.545Z).
- Accepted P3 convention advisory: a static schema assertion should use a top-level import rather than the module-reload exception without resetModules. This assertion is not intended as a load-time behaviour test; actual manual mutant receipts and fresh native baselines independently cover the production guards. Deferred as advisory without changing the frozen runtime or test scope. From fd202ffabeac9430 at b6d4e8c2e161, by Tal Rotbart (2026-10-27T05:08:45.447Z).

## Counts

Comparisons: 1. Pending matches: 0.
claude-code: recall 6/16 \(0.375\), precision 6/8 \(0.750\), pending 0.
codex: recall 0/16 \(0.000\), precision 0/0 \(1.000\), pending 0.
melian: recall 11/16 \(0.688\), precision 11/11 \(1.000\), pending 0.
owned-missed: 5.
no-owner: 0.
needs-execution: 0.
out-of-scope: 0.
Valid misses without a reason: 0.

## Differences

At fd68b824c82f: 1 matched external findings, 5 external-only defects, 5 Melian-only findings.

Matched: 1 external finding, covering 1 Melian finding. External only: 5. Melian only: 5.
Matched:
  2240c811cfd82c0e
    2be3ed6ea18dd693  claude-code  packages/cli/src/pull-request-comparison.ts:97-101
External only:
  0f451bc9fff91302  claude-code  packages/cli/src/compare.ts:264-269  Stats counts a round as unattributed even when another pull request's snapshot holds it as a member
  b1bf678a4569bf1e  claude-code  packages/cli/src/pull-request-comparison.ts:63-64  A bare membership read with nothing to accept fails without a git author
  c2eb5b511c708184  claude-code  packages/core/src/pull-request-rounds.ts:103-116  An unfetchable pull-request base is recorded as every member's own missing commit
  5b7847c7980c927d  claude-code  packages/pipeline/src/compare.ts:282-283  close\(\) lost its TSDoc, which now sits stacked above refreshMembership
  eac842d89b975ae6  claude-code  packages/pipeline/src/pull-request-rounds.ts:111-117  Every other pull request's rounds in the clone enter each snapshot's foreign set
Melian only:
  bef6530d4b49c3a9  P3 guardrail/forbidden-patterns  docs/design/comparison-with-external-reviewers.md:57
  34ea6c05ef73e2fa  P3 quoted-rule-violation  packages/cli/src/comparison-stores.ts:14
  791d6934d88cc273  P3 quoted-rule-violation  packages/cli/src/pull-request-comparison.ts:17
  5b874eb3710885af  P3 enola/performance  packages/github/src/rounds.ts:71
  e70e25181cfdec99  P3 enola/complexity-outliers  packages/pipeline/src/pull-request-rounds.ts:60

At 42cef9eb6171: 0 matched external findings, 1 external-only defects, 2 Melian-only findings.

Matched: 0 external findings, covering 0 Melian findings. External only: 1. Melian only: 2.
External only:
  2ea487afb7d97ae1  claude-code  packages/cli/src/pull-request-comparison.ts:114-118  Post-snapshot JSON export re-serialises the escaped record and emits raw bidi and C1 controls from reviewer text
Melian only:
  5b874eb3710885af  P3 enola/performance  packages/github/src/rounds.ts:71
  e70e25181cfdec99  P3 enola/complexity-outliers  packages/pipeline/src/pull-request-rounds.ts:60

At b6d4e8c2e161: 0 matched external findings, 1 external-only defects, 3 Melian-only findings.

Matched: 0 external findings, covering 0 Melian findings. External only: 1. Melian only: 3.
External only:
  15743af4e9678ee8  claude-code  packages/cli/src/pull-request-comparison.ts:97-102  After any membership snapshot, export silently drops the pull request's own comparisons from rounds minted later
Melian only:
  5b874eb3710885af  P3 enola/performance  packages/github/src/rounds.ts:71
  e70e25181cfdec99  P3 enola/complexity-outliers  packages/pipeline/src/pull-request-rounds.ts:60
  fd202ffabeac9430  P3 quoted-rule-violation  packages/pipeline/test/pull-request-schema.test.ts:4
