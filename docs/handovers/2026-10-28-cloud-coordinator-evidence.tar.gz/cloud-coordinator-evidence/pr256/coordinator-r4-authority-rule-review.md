# R4 stored-ownership authority rule review

## Receipt

- Result: **PASS with the inclusion design below**.
- Reviewed head: `b6d4e8c2e1612fba1bd91625756dc07b62ce8191`.
- Runtime: GPT-6 Codex agent. No native Codex CLI companion or live model/provider was used.
- Evidence: the strict Opus R3 finding and its real CLI stale-snapshot/control probes; the frozen core, pipeline and CLI source; the exact-round and unattributed-export decisions; and a pure offline ten-scenario model probe.
- Probe: `/tmp/issue-231-r4-authority-rule-probes/rule-model.mjs`; output: `/workspace/melian/tmp/issue-231/coordinator-r4-authority-rule-probe.log` (`PASS`).

## Decision

Use stored ownership as the live authority while keeping the saved snapshot as the last GitHub/Git attribution answer. Do not refuse merely because a newly stored-owned round is absent from the snapshot. Refusal would make an export that has sufficient local proof depend on GitHub, contrary to the offline export contract. Inclusion is coherent because rule 1 in the exact-round decision already makes pull-request provenance or a recorded publication target conclusive without Git.

The snapshot and every history version remain byte-for-byte stored data. New stored-owned rounds enter only the exported comparison set. They receive no snapshot member, number, status, or synthetic history entry.

## Core authority

Add one public, pure static query to the existing stateful `PullRequestMembership` class, for example:

```ts
static storedOwnership(
  candidate: MembershipCandidate,
  pullRequest: Pick<PullRequestRoundHeads, "repository" | "number">,
): boolean | undefined
```

Its contract is tri-state:

- `true`: stored pull-request provenance or publication names this repository and number;
- `false`: stored ownership names another pull request or has incomplete pull-request provenance;
- `undefined`: no stored ownership decides the candidate, so Git attribution is required.

Pull-request provenance takes precedence over publication. Range provenance does not: publication remains the next authority. Repository owner and name compare case-insensitively; the number compares exactly. `classify` must call this query and preserve its current reasons and commit-date lookup. Callers must compare with `=== true` and `=== false`, so `false` cannot collapse into `undefined`.

A static query is the right API. Opening an instance requires GitHub's full heads answer and may perform Git operations, which offline export must avoid. This method belongs on the existing membership authority rather than a new namespace class or a duplicated CLI predicate. As exported core API, it needs TSDoc that states the three results and that `undefined` is not foreign.

## Export selection

When no snapshot exists, preserve the compatibility scope: inspect only the pull request's own store. Keep raw unattributed records and attributed records with `true` or `undefined` ownership; exclude attributed records whose stored ownership is `false`. This keeps the documented pre-snapshot export without letting an explicitly foreign provenance enter by filename. Do not expand to other stores before the first snapshot.

When a snapshot exists:

1. Build the ownership result for every candidate read from all stores.
2. Before rendering or touching the destination, refuse if any saved member now has `false` stored ownership. Name each conflicting round and direct the user to `melian compare refresh "#N"`, then `--accept` if refresh reports a rejection. Stored ownership outranks the old Git answer; silently retaining or dropping that member would bypass the acceptance audit.
3. Select attributed entries whose ID is either a saved member ID or a candidate with `true` stored ownership.
4. Treat `undefined` as the saved snapshot's old Git answer: keep it only when its ID is a saved member. Do not admit a new unknown candidate.
5. Make raw records eligible from the pull request's own store and every store holding either a saved member or a newly known-owned round. This retains unreachable/deleted candidates and expands member-holding stores without guessing a raw round.
6. Exclude foreign-only stores. The own-store raw compatibility exception remains explicit.

A missing candidate for a prior member is not evidence of foreign ownership. Keep the saved member and its store, which preserves the existing unreachable rule.

## Ordering and stale notice

Keep raw compatibility ordering as today. Order saved attributed members by their stored snapshot number. Append newly known-owned attributed rounds in round-ID order. Do not assign them numbers or add them to the snapshot.

Detect staleness from the actual selected output: compare the new selection with the selection the saved snapshot alone would have produced. This catches both a new attributed round and raw records admitted from its newly eligible store. If the export adds any such record:

- write a clear stderr warning that the saved membership snapshot does not contain every stored-owned comparison record and that bare `melian compare "#N"` refreshes it;
- in Markdown, label the membership snapshot with its stored `at` time and state that additional stored-owned rounds are included without snapshot numbers;
- keep the JSON object shape unchanged. Its existing `membership.at`, `membership.version`, and `history` remain the as-of record.

Build and render the full output before stdout or `writeFile`. The saved-member conflict and `ComparisonExport.renderJson()` collision must therefore refuse before a destination write. Emit the stale warning only after successful output. Preserve lazy Markdown rendering and the final per-JSON-line `visibleText` pass after the last `JSON.stringify`.

## Attacks checked

The offline model covered:

- a new second round in the pull-request store after snapshot 1;
- a newly published owned round in a range store;
- foreign pull-request provenance plus current publication, and the reverse precedence;
- an old Git member later given explicit foreign publication ownership;
- a prior unreachable member whose candidate is absent;
- raw unattributed records in the own store;
- pre-snapshot own-store compatibility with an explicitly foreign attributed record;
- a new unknown candidate versus an old unknown saved member;
- saved members before deterministic unnumbered additions; and
- two newly eligible stores with the same raw revision key, which still reaches typed JSON collision refusal.

The model passed all ten scenarios. The production tests should also prove stdout and `--out`, JSON and Markdown, unchanged parsed JSON values and final control escaping, history/adjudication preservation, collision leaving an existing file untouched, and no GitHub/Git-author call during export.

## Documentation scope

Amend the exact-round decision: offline export combines the last persisted membership snapshot with later conclusive stored ownership, while the snapshot and history stay as-of and unmodified. Amend the unattributed-export decision for newly eligible member-holding stores. Update the CLI guideline and design summary with the warning and Markdown wording. This changes no stored schema, JSON field, comparison namespace, stats aggregation, or build-4 write routing.
