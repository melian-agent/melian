# Codex adversarial review R4 — pull request 256

## Result

**PASS. No unresolved code findings.**

- Head: `66236a1804e4135c112b6d1d6cca7c9e58013042`
- Tree: `263826d341d92d195c8488e565262b51ffa61345`
- Base: `319b14d236efb259f79a695b1020144caa0ee2c7`
- Runtime: GPT-6 Codex agent. The exact serving model identifier is not exposed in this agent runtime. The native Codex CLI companion was unavailable, so this report does not claim a native GPT-5.6 or other companion run.
- Review worktree: `/workspace/melian-worktrees/issue-231-review-r1`, clean before and after review.

The pushed tree is byte-identical to frozen scratch commit `078dc3567f3663b0199851ffb495c457b7c7f6fd`. Its production files are identical to immutable precommit source `a6770d0f0dacb557aeaa5963f840c9526090d519`; the only difference from that source is the added `pull-request-export-guards.test.ts` regression file.

## Scope and conclusion

I reviewed the complete base-to-head feature diff across core, GitHub, pipeline, CLI, tests and documentation. Earlier R1–R3 review reasoning was rechecked against the exact final tree, and the complete R4 production change and final guard tests were reviewed again. The final diff contains 46 files and about 4,000 added lines.

The feature contracts hold:

- GitHub history is paginated and validated, the 250-commit cap fails closed, force-push heads and associations are retained, and repository identity is case-insensitive.
- Membership uses stored provenance/publication before exact Git attribution, retains all merge bases only when their trees agree, handles merged and fast-forward cases, and preserves accepted unreachable members and numbering.
- Snapshot refresh and explicit acceptance preserve history and audit rejected prior members atomically.
- Offline export and statistics avoid GitHub. Pull-request flags remain scoped, and intentional explicit `--round` range writes remain available.
- Pull-request publication provenance outranks publication records; historical publication ownership, legacy targets and detached storage scans retain their established contracts.
- Raw unattributed records remain in own/member-holding stores, foreign-only stores stay out, duplicate raw JSON keys refuse before output, Markdown remains available, and stored adjudication histories remain unchanged.
- The final JSON boundary applies core `visibleText` after the last serialization without changing decoded values or structural newlines.

R4 fixes the stale-snapshot class at its authority boundary. `PullRequestMembership.storedOwnership` returns true, false or undefined without I/O, and `classify` uses the same predicate. Pull-request provenance wins over publication; range provenance permits publication; repository names compare case-insensitively; incomplete pull-request provenance is explicitly foreign. The CLI admits later rounds only on true stored ownership, keeps unknown rounds only when the saved snapshot already accepted them, and preserves a missing prior candidate as unreachable. A saved member whose current stored ownership is foreign refuses before rendering or destination output and directs the user through refresh and `--accept`.

Before a first snapshot, export remains confined to the own pull store. It retains raw and unknown legacy records while excluding explicitly foreign attributed entries. With a snapshot, raw eligibility expands through saved and newly known-owned stores. Warnings depend on actual newly selected records, including raw-only additions, rather than candidates with no comparison. Markdown labels the stored as-of time; JSON keeps the exact saved snapshot and history, with no synthetic number, version, field or namespace. Saved attributed entries remain in snapshot order and new owned entries follow in deterministic ID order. Collision refusal, lazy Markdown rendering and final line-wise escaping remain intact.

The accepted P3 availability limitation for a globally missing current pull-request base remains documented. The earlier ownership-first and pull-request-relative statistics reports remain adjudicated contract questions, with no new evidence against those rulings. The pre-existing dynamic-import schema-test advisory is unchanged and does not affect this review.

## Focused baseline

I ran the 19 R4 focused files from `r4-final-bindings.json`, plus the 44-test CLI comparison compatibility file, under the process reaper with `--maxWorkers=2` and a unique module cache:

```text
python3 /workspace/.melian-tools/reap.py node_modules/.bin/vitest run
  packages/cli/test/compare-unit.test.ts
  packages/cli/test/main.test.ts
  packages/cli/test/pull-request-comparison-unit.test.ts
  packages/cli/test/pull-request-comparison.test.ts
  packages/cli/test/pull-request-stale-export.test.ts
  packages/cli/test/pull-request-unattributed-export.test.ts
  packages/core/test/comparison-export-collision.test.ts
  packages/core/test/comparison-export.test.ts
  packages/core/test/harness-free.test.ts
  packages/core/test/pull-request-rounds-fetch.test.ts
  packages/core/test/pull-request-rounds-io.test.ts
  packages/core/test/pull-request-rounds.test.ts
  packages/github/test/rounds-case.test.ts
  packages/github/test/rounds.test.ts
  packages/pipeline/test/pull-request-publication-contract.test.ts
  packages/pipeline/test/pull-request-rounds.test.ts
  packages/pipeline/test/pull-request-schema.test.ts
  packages/pipeline/test/pull-request-snapshot-contract.test.ts
  packages/cli/test/pull-request-export-guards.test.ts
  packages/cli/test/compare.test.ts
  --maxWorkers=2 --fsModuleCache
  --fsModuleCachePath=/workspace/.issue-231-codex-r4-cache
```

Result: **43 suites, 306/306 tests passed, 0 failed, 0 skipped**.

- JSON report: `/workspace/melian/tmp/issue-231/codex-r4-baseline.json`
- JSON sha256: `aa3181d474f8391c5721f4da4043bce5b0ffd89e2297813f283294e2d10f0c28`
- Log: `/workspace/melian/tmp/issue-231/codex-r4-baseline.log`
- Log sha256: `ff962cb6b392ab5e46c3a985c57f60636a11b05d738df727691e69249b4faa9c`

The first launch did not start Node or Vitest because I replaced rather than prepended the host PATH (`env: node: No such file or directory`). I corrected the invocation and ran the full command above. The failed launch executed zero tests and is not counted as evidence.

The baseline includes the genuine offline CLI flow: review/import round 1, save snapshot 1, push, review/import round 2, replace round 2's adjudication, remove GitHub availability, and export JSON/Markdown to stdout/file. It verifies both rounds and the complete current/history adjudication data.

## Independent probe

I ran `/tmp/issue-231-codex-r4-probes/authority-export.mts` against the exact source under the reaper. It used the production core predicate and production CLI export implementation, with in-memory detached store data and temporary output files. It made no GitHub request, resolved no former Git ref, opened no state writer and called no model/provider.

The probe checked:

- true, false and undefined stored ownership, case-insensitive repository matching, provenance/publication precedence and incomplete provenance;
- saved unknown/unreachable membership, later own-store ownership and later published range ownership;
- exclusion of new unknown, explicit foreign and foreign-provenance/current-publication candidates;
- own, saved-member and newly owned raw stores, with foreign-only raw exclusion;
- exact snapshot/history output and no ordinal or stored-object mutation;
- saved-member foreign refusal before overwriting an existing file;
- pre-snapshot own-store raw/unknown compatibility and foreign exclusion;
- stable saved-first/new-ID attributed ordering;
- typed raw-key collision before file output, with lazy Markdown still rendering both records;
- stdout and file JSON equality, decoded value equality, literal escape preservation, structural newlines, Markdown safety, and all 79 code points handled by `visibleText`.

Result: **PASS**.

- Probe source: `/tmp/issue-231-codex-r4-probes/authority-export.mts`
- Source sha256: `28630db391291a97872f167f2fa73f5121ebadf42c422b34411b0f7360f23a5b`
- Output: `/workspace/melian/tmp/issue-231/codex-r4-authority-export.log`
- Output sha256: `b921a4fa01c191de6a0be96c2f9d333d70c51bc660b18efc13104fde62ff80ba`

The first probe launch failed before assertions because direct Node loading lacked Melian's workspace `@melian-agent/source` resolution hook and sought an unbuilt workspace `dist/index.js`. I added the same source condition used by the CLI launcher and reran the unchanged assertions successfully. The failed launch is retained at `/workspace/melian/tmp/issue-231/codex-r4-authority-export-launch1.log` and is not evidence of product failure.

## Mutation evidence and limits

The final independent consistency audit at `/workspace/melian/tmp/issue-231/coordinator-proof-audit/r4-final-audit.json` reports success for the exact head: 1,037 generated identities, 830 fresh manual kills, 14 observed survivors classified as reviewed equivalents, 193 base-policy exclusions and zero errors. The independent enumeration reports zero omitted identities. The bindings explicitly state that R1 and R3 proofs were not carried into R4.

The final-escape removal is separately and correctly labelled `SUPPLEMENTAL_NOT_GENERATED`. Its 12-test baseline passed; removing the final escape pass produced the two expected stdout/file failures and left ten passing tests. This supplemental result does not enter the 1,037 generated identities.

The proof audit is a manual builder-evidence consistency audit. It did not execute tests and did not create a hardened verifier-cache record. I reviewed its final summary and source bindings but did not rerun or bulk-audit the 1,037 mutations. The mutation counts support the source review and executable probes; they do not replace them.

I did not run the full monorepo gate, make a live GitHub or network request, call a live model/provider, edit tracked source or tests, commit, switch branches, or publish any result online.

## Corrected historical findings

These are fixed historical findings, not unresolved R4 findings:

- Early repository-case matching, missing merged-commit fetching and owned legacy date handling were corrected before the first pushed reader chunk.
- Duplicate membership classification and the legacy-target ruling were corrected before the first formal review.
- R1's loss of raw unattributed own/member-store comparisons was fixed with typed cross-store collision refusal and Markdown preservation.
- R1's exported API documentation and Git-author-on-read findings were fixed.
- R2's raw Unicode/control output defect was fixed by the final JSON line boundary.
- R3's omission of later conclusively owned comparisons behind a stale snapshot is fixed by the shared stored-ownership authority reviewed here.
