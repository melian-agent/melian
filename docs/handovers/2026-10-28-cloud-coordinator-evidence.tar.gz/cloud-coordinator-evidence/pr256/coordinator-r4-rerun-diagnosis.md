# PR 256 R4 rerun diagnosis

## Conclusion

`--rerun` did what the current implementation supports: it replaced the **whole aggregate lens task** because at least one selected lens had failed. It does not retry only the failed lens. The replacement task contains all eight selected lenses, and `LensTask` submits all of them concurrently with `Promise.all`. There is no supported CLI or configuration setting that caps or serializes lens concurrency.

The supported recovery is therefore to wait for sufficient provider capacity, apply the repository-required temporary lens budgets, and invoke the same exact-range review with `--rerun` again. That creates another complete eight-lens task and runs all eight concurrently. A repeat without `--rerun` only attaches to the terminal failed task and preserves the `not-reviewed` result. There is no supported way to combine attempt 1's seven completed results with a later design-only run.

If the provider cannot accommodate the concurrent full round, pause the workflow. Neither attempt is a passing Melian review.

## Evidence

- Attempt 1, `/workspace/melian/tmp/issue-231/melian-r4-attempt1-rate-limit.log`, completed seven lenses and exhausted `design` on an Anthropic 429.
- Attempt 2, `/workspace/melian/tmp/issue-231/melian-r4-attempt2.log`, attempted all eight lenses on Opus and each exhausted on a separate 429.
- Read-only inspection of `/workspace/melian/.git/melian/range-10a17438c2ea67d2.sqlite` corroborated the logs:
  - task 773 contains all eight lenses, with seven `done` outcomes and `design@658bafe9892c@careful` `exhausted`;
  - replacement task 926 contains all eight lenses, each `exhausted`.
- `packages/pipeline/src/review.ts` computes one selection for all lenses. With `rerun`, `anyLensFailed(...)` prevents attachment, clears the selected lenses' sightings, creates a new `LensTask` with the full input, updates `ReviewIndex`, and aborts the prior task. The task then evaluates `Promise.all(input.lenses.map(chain))`.
- The lens instruction fingerprint includes each level's budget, so the temporary budget overrides are part of run identity. A conforming retry must apply the required overrides exactly as `AGENTS.md` directs; restoring them afterward remains required.
- `docs/guidelines/pipeline.md` explicitly describes the lens task as creating every conversation and running them in parallel. Its statement that `--rerun` runs “failed lenses” is shorthand at the review level; the storage/task granularity is the whole selected lens set.

All eight immediate 429s in attempt 2 are consistent with a burst or token-reservation limit because the implementation submits all eight concurrently, but the local evidence cannot establish Anthropic's internal accounting. No lens-concurrency option was found in the review CLI, `melian.yaml` configuration, or the lens task implementation. Existing concurrency options concern other checks and do not govern model lenses.

## Policy boundary

Root `AGENTS.md` requires three distinct reviews: Codex adversarial review, Melian's own review, and the Claude review of record. Its Anthropic-constrained fallback through `scripts/codex-sandboxed.sh` applies to the independent Claude review-of-record lane. It does not replace the separately required Melian self-review. The completed Codex R4 review likewise remains the Codex lane; it cannot turn these failed Melian tasks into a reviewed verdict.

This diagnosis made no repository or storage writes, launched no model calls, and did not inspect credentials. The only write is this coordinator report.
