# Codex adversarial review, round 2

Review of [pull request #250](https://github.com/melian-agent/melian/pull/250) for [issue #239](https://github.com/melian-agent/melian/issues/239).

## Receipt

- Head: `173409eacda4dc04a24173ccf2fa3d0cbd183461`
- Base: `319b14d236efb259f79a695b1020144caa0ee2c7`
- Reviewer: the available Codex agent runtime, identified by the runtime as GPT-6. The runtime exposes neither a point model nor a reasoning-effort label, so this receipt does not invent either.
- Result: approve; no unresolved code findings.
- Import: `tmp/issue-250/codex-r2-review.json`, with an empty strict findings array.

The native CLI companion was unavailable in this environment. Its read-only native-state check completed, but an independent-state attempt reported invalid backend credentials. This review therefore used the available Codex agent rather than claiming a GPT-5.6 companion run.

The coordinator supplied a frozen isolated worktree at the exact head. It contained seven intentional lens-budget overrides only; I did not change or review those as pull-request source. I used no Git mutation, branch switch, online publication, or paid provider command.

## Scope and result

I rechecked the whole branch: the version-2 core inventory, enumeration adapter and target selection, CLI commands and parsing, compatibility scripts, exports, manifests and lockfile, focused tests, design, decisions, guidelines and progress record. The six original production files match the archived final snapshot except `packages/pipeline/src/mutation-enumeration.ts`, whose current SHA-256 is `e684fef4b553f72d20fd70311a127411d77f7e36829ee9e846f1ad56bf4dc8ad`. That hash matches the final fix receipt. The current source contains exactly the three expected behavioural fixes after `0ca63f550fed50e9bd0ac273f4908252eec484e2`. Core's `gitOutput` TSDoc and package export are the small supporting API change.

I found no regression in inventory validation, identity hashes, sampling, legacy compatibility, base policy, adapter provenance, installation identity, JavaScript selection, no-adapter handling, CLI exits, or compatibility output.

## Fix recheck

### Repository-local Git environment

`TypeScriptMutationAdapter.open` now asks core's existing `gitOutput` authority whether `node_modules` is tracked. That authority removes `GIT_DIR`, `GIT_WORK_TREE`, `GIT_INDEX_FILE` and the complete repository-local variable list, sets `GIT_OPTIONAL_LOCKS=0`, and carries command failures. The adapter translates either a failed command or spawn into a typed instrumenter refusal.

The regression uses a tracked marker-writing instrumenter and separately redirects a foreign repository and foreign index. Both failed before the fix by creating the marker. The final targeted run passed 47 tests. Its inventory records seven generated mutants killed and six configured string mutations ignored.

### Babel configuration boundary

The adapter writes `{}` to `scratch/package.json` before it starts the worker. A failed write prevents `execFile` and the `finally` block removes scratch.

Pinned Stryker 10.0.0 leaves Babel config enabled for JavaScript while its TypeScript parser disables it. Pinned Babel 8.0.6 searches root configs only at its `cwd`; relative `.babelrc*`, `.babelignore` and package `babel` data are confined by the nearest package. The empty package therefore closes the discovered ancestor walk without changing the parser.

The committed tests cover executable `.babelrc.js`, `.cjs` and `.mjs`, JSON and extensionless `.babelrc` files that load a plugin, a package `babel` field, a config above `TMPDIR`, JS, JSX, marker absence, scratch cleanup, successful enumeration, and boundary-write failure before spawn. The targeted run passed 55 tests. Stryker emitted only two configured string mutations on the new statement, so the builder also removed the whole awaited statement manually; the marker regression failed and killed that mutation.

My independent disposable probe, `/tmp/pr250-babel-boundary-probe.mjs`, ran 23 fresh Stryker child cases. Six controls executed ancestor `.babelrc` or package plugins without a boundary. All 15 boundary cases avoided execution, including JS, JSX, absolute filenames, `..` escapes and a symlinked worker path. Ancestor `babel.config.cjs` never ran because Babel's default root was scratch. I found no bypass.

### Executable production selection

Unknown executable files now pass through `productionWithExtensions(path, /.*/)` before extension or executable-kind detection. This reuses the same test, fixture, golden, generated-directory, declaration and verifier-corpus exclusions as JavaScript selection. Extensionless production executables remain unsupported and visible.

The regressions cover a test-only executable with and without a supported production neighbour, all shared excluded directories and suffixes, a newline-only executable production name, ordinary extensionless production and uppercase documentation. The final scoped run passed 69 tests. Stryker killed the regex mutation, and a manual replacement of the whole production predicate made the test-only case fail.

## Corrected historical findings

These are fixed and do not appear in the JSON findings array.

- My round-one P1 showed that ambient Git repository variables could make tracked reviewed install code look untracked. The exported Git authority and marker regressions close it.
- Claude's round-one P1 executed tracked `.babelrc.js` through JavaScript enumeration. The private package boundary and independent attack above close all tested variants.
- Claude's round-one P3 treated executable tests and fixtures as unsupported production. Shared production exclusions now apply before executable discovery.
- Earlier review found pull-request policy using the merge base, unsafe instrumenter fallback and workspace links, unsupported languages silently succeeding, and weak version-2 path and adapter provenance. The exact head retains each fix and its regression.

Claude's C3 about `scripts/instrument-mutants.mjs` having no internal caller was adjudicated noise. It is an intentional standalone stdin compatibility utility; absence of an in-repository caller does not make it dead code, and removing intentional functionality requires approval.

## Evidence and limits

Evidence executed for this round:

- Coordinator exact-head focused baseline: 11 suites, 247 passed, zero failed and zero skipped, recorded in `tmp/issue-250/baseline-final.json`.
- My 23-case pinned Stryker/Babel boundary probe described above.
- Byte comparison of all six production files against both archived snapshots, plus the final source hash check.

Evidence inspected, rather than rerun by this reviewer:

- The three fix passes' fail-before logs, passing targeted logs, type checks, scoped lint and mutation receipts under `tmp/issue-250/{git-env-fix,babel-fix,executable-fix}`.
- The predecessor head's complete proof: 606 killed, nine equivalent and 171 policy-ignored mutants, with no survivor, timeout, unloadable or pending result.
- The predecessor head's packaged CLI smoke and successful Node 22, 24 and 26 CI jobs. The later fixes do not change package shape, but exact-head CI was not claimed here.

At the time of this receipt, the coordinator's final 15-mutant consolidation window for whole spans introduced by the fixes was still running. I did not count it as completed evidence. The targeted mutation records above cover each new behavioural guard. I did not duplicate the broad suites while the primary checkout was running them.
