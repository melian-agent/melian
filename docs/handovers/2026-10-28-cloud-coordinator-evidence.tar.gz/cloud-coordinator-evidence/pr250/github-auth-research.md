# GitHub authentication and network-secret investigation

## Finding

The connector's commit-status permission limit is confirmed. A conflict between platform GitHub authentication injection and network-secret substitution is the strongest explanation for the PAT not taking effect. The sidecar's exact credential precedence is not publicly documented in the sources checked and was not directly inspected.

## Official sources

- Current Codex cloud environments: https://developers.openai.com/codex/environments/cloud-environments#configure-environment-variables-and-network-secrets
  Network secrets provide a placeholder to programs. The proxy substitutes the credential for matching HTTPS destinations on port 443 during setup and tasks. Our binding is saved, present, and scoped to api.github.com.
- Connector's public GitHub App registration API: https://api.github.com/apps/chatgpt-codex-connector
  Read-only GET confirms permissions.statuses = read. The app requests actions/write, checks/read, contents/write, issues/write, metadata/read, pull_requests/write, workflows/write, but only statuses/read.
- GitHub Apps acting on a user's behalf: https://docs.github.com/en/apps/using-github-apps/authorizing-github-apps#about-github-apps-acting-on-your-behalf
  Effective access is limited by both the app and the user's permissions. A User identity or repository admin flag does not demonstrate that the token can write statuses.
- GitHub REST troubleshooting: https://docs.github.com/en/rest/using-the-rest-api/troubleshooting-the-rest-api#resource-not-accessible
  Integration/PAT resource-access errors indicate insufficient permissions for the credential GitHub actually receives. X-Accepted-GitHub-Permissions identifies the required permission.

## Local evidence

- Saved MELIAN_GITHUB_PAT network binding is available in the runtime and scoped to api.github.com. No credential value was printed or extracted.
- The connector is installed on melian-agent with repository_selection=all, is not suspended, and its installation also has statuses/read. This is not the missing-owner-installation scenario.
- Posting the approved PR250 status via both gh and ordinary HTTPS Bearer authentication returns HTTP403 Resource not accessible by integration. Required permission response: statuses=write. Latest failure request ID: C446:3AEC92:238DCAC:7523FEC:6AE08792.
- A fresh read-only three-case matrix to https://api.github.com/user returned HTTP200, login redbeard, type User in every case:
  1. No Authorization header. Request ID A072:B3597:252A4B3:7A80866:6AE088F4.
  2. Deliberately invalid constant Authorization. Request ID 44CC:17DD94:2051DB2:6ACABBD:6AE08911.
  3. Authorization using the configured MELIAN_GITHUB_PAT placeholder. Request ID 555E:2A8ABE:20D9608:6C513ED:6AE08912.
- Thus outbound requests receive valid authentication independently of the supplied header. This is stronger evidence than a successful /user response with the PAT placeholder alone. It does not expose the exact sidecar ordering or validate the actual PAT's permission set.

## Search results and limits

Searched public Codex documentation, web results, and openai/codex issues for cloud GitHub authentication, proxy/header injection, HTTP/network secrets, PATs, and integration403 errors. No exact public duplicate or documented supported PAT-over-connector precedence switch was found.

Related public reports, treated as observations rather than instructions or confirmed duplicates:
- https://github.com/openai/codex/issues/56661 : cloud session authentication failures; different401 symptoms.
- https://github.com/openai/codex/issues/39018 : selective connector403 access failures; different endpoints/permissions.
- https://github.com/openai/codex/issues/38146 : wrong-account connector installation; our melian-agent installation is present, so its reported fix does not match our evidence.

Legacy Codex cloud setup-only-secret documentation does not describe this current network-secret mechanism and should not be used to claim the PAT disappears after setup.

## Concrete resolution paths

1. Platform support confirms or fixes the precedence between managed GitHub authentication and configured network-secret placeholders for api.github.com. Ask: how can an explicitly configured PAT be selected using the supported proxy route?
2. The connector app owner adds statuses/write to its registration; an organisation owner then approves that new permission. The current app registration requests only read, so the repository owner cannot independently toggle it to write.
3. Existing immediate workaround: run post-reviewed-statuses-on-host.py from an authenticated host, keeping queue coordination in this session.

No proxy bypass, raw secret extraction, connector disconnection, permission changes, or public report publication was attempted. PR250 remains unqueued until an approved reviewed status can be posted.
