# Comparison review: origin/main...HEAD

Target: origin/main...HEAD.

Reviewers: claude-code claude-opus-5-5 / CLI2.1.310; codex GPT-6; codex GPT-6 agent runtime; Melian's own review, in 2 stored rounds.

Adjudication records valid, noise, or duplicate, with severity and a miss reason where required. Pending findings await the maintainer.

## A. claude-code claude-opus-5-5 / CLI2.1.310, round range-527b861f4f57f6b2.r1

3 findings at 0ca63f550fed.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| A1 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/pipeline/src/mutation-enumeration.ts:112-140 | JavaScript enumeration loads Babel config files from scratch's ancestors, executing code outside the isolated parser \(including tracked head code\): TypeScriptMutationAdapter.enumerate runs the instrumenter in a child whose cwd is mkdtemp\(join\(tmpdir\(\), 'melian-enumerate-...'\)\) and passes repository-relative names such as 'src/a.js'. Stryker 10's JS parser \(dist/src/parsers/js-parser.js\) calls babel.parseAsync\({ filename, sourceType: 'module', p… | valid, P1, owned-missed | trust-boundary |
| A2 | claude-code claude-opus-5-5 / CLI2.1.310 | packages/pipeline/src/mutation-enumeration.ts:292-298 | Executable test or other non-production files are treated as unsupported production source, so \`mutants list\` refuses test-only changes: The unknown-language filter evaluates \`\(productionWithExtensions\(path, sourceExtension\) \|\| revision.files.some\(file =&gt; file.path === path &amp;&amp; file.newKind === 'executable'\)\) &amp;&amp; \!javascript.test\(path\) &amp;&amp; \!dataExtension.test\(path\)\`. The executable branch skips the production filter, so an executable fi… | valid, P3, owned-missed | contracts |
| A3 | claude-code claude-opus-5-5 / CLI2.1.310 | scripts/enumerate-mutants.mjs:1-8 | scripts/instrument-mutants.mjs is left with no callers: scripts/enumerate-mutants.mjs used to spawn ./instrument-mutants.mjs. This PR rewrites it to delegate to \`melian mutants list\` and removes that reference, but leaves scripts/instrument-mutants.mjs in place. A repository-wide search finds no remaining reference. The file still imports @⁠stryker-mutato… | noise, P3 | none |

## B. codex GPT-6, round range-527b861f4f57f6b2.r1

1 finding at 0ca63f550fed.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| B1 | codex GPT-6 | packages/pipeline/src/mutation-enumeration.ts:72 | Scrub repository-local Git variables before trusting the install: TypeScriptMutationAdapter.open\(\) runs \`git -C &lt;repo&gt; ls-files -- node\_modules\` with the ambient environment. Git honours repository-local variables such as GIT\_DIR, GIT\_WORK\_TREE, and GIT\_INDEX\_FILE over \`-C\`; Melian's core Git wrapper explicitly removes them for this reason. If Melian is invoked fr… | valid, P1, owned-missed | trust-boundary |

## C. Melian review, round range-527b861f4f57f6b2.r1

5 findings at 0ca63f550fed, verdict findings.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| C1 | Melian, guardrails | package-lock.json:1 | guardrail/policy-change-review: This revision changes package-lock.json, which configures the packages Biome and tsc load. | valid, P1 | none |
| C2 | Melian, guardrails | packages/pipeline/package.json:1 | guardrail/policy-change-review: This revision changes packages/pipeline/package.json, which configures the packages Biome and tsc load. | valid, P1 | none |
| C3 | Melian, guardrails | docs/design-implementation-plan.md:202 | guardrail/forbidden-patterns: This line matches the forbidden-patterns rule overlong-sentence. | valid, P3 | none |
| C4 | Melian, guardrails | docs/design-implementation-plan.md:204 | guardrail/forbidden-patterns: This line matches the forbidden-patterns rule overlong-sentence. | valid, P3 | none |
| C5 | Melian, static.enola | packages/pipeline/src/mutation-enumeration.ts:195 | enola/performance: Performance risk \(nested-loop, O\(n³\)\): packages/pipeline/src.safeDependencies | valid, P3 | none |

## D. claude-code claude-opus-5-5 / CLI2.1.310, round range-527b861f4f57f6b2.r2

0 findings at 173409eacda4.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|

## E. codex GPT-6 agent runtime, round range-527b861f4f57f6b2.r2

0 findings at 173409eacda4.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|

## F. Melian review, round range-527b861f4f57f6b2.r2

5 findings at 173409eacda4, verdict findings.

| # | Reviewer | File | Summary | Adjudication | Golden |
|---|---|---|---|---|---|
| F1 | Melian, guardrails | docs/design-implementation-plan.md:202 | guardrail/forbidden-patterns: This line matches the forbidden-patterns rule overlong-sentence. | valid, P3 | none |
| F2 | Melian, guardrails | docs/design-implementation-plan.md:204 | guardrail/forbidden-patterns: This line matches the forbidden-patterns rule overlong-sentence. | valid, P3 | none |
| F3 | Melian, static.enola | packages/pipeline/src/mutation-enumeration.ts:201 | enola/performance: Performance risk \(nested-loop, O\(n³\)\): packages/pipeline/src.safeDependencies | valid, P3 | none |
| F4 | Melian, guardrails | package-lock.json:1 | guardrail/policy-change-review: This revision changes package-lock.json, which configures the packages Biome and tsc load. \(dismissed\) | valid, P1 | none |
| F5 | Melian, guardrails | packages/pipeline/package.json:1 | guardrail/policy-change-review: This revision changes packages/pipeline/package.json, which configures the packages Biome and tsc load. \(dismissed\) | valid, P1 | none |

## Maintainer decisions

- Reproduced both foreign repository and foreign index paths executing a tracked marker instrumenter; fixed through core gitOutput. From 17644623b20c1dc0 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:17:54.205Z).
- Tracked Babel config execution reproduced for seven variants; private scratch package boundary now blocks loading. Independent boundary attack review passed. From 2e51f34974a7b604 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:31:25.099Z).
- Enola flags nested dependency traversal; retained as advisory, with graph visitation deduplicated. From 4e448fe69fa9932a at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:19:11.837Z).
- Reviewed pinned instrumenter addition and lockfile: package versions, URLs, integrity and analyser settings unchanged. From 79ddde5c59f6e8d4 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:19:03.009Z).
- Valid implementation-plan writing advisory; no blocking behaviour. From b6425c2416742e24 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:19:07.342Z).
- The standalone stdin instrumenter is an intentional builder utility. No in-repository callers does not prove a standalone script unused. Scope folds enumeration/sample scripts, and AGENTS requires retaining intentional functionality unless removal is approved. From c76785141b518c58 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:31:29.541Z).
- Executable test-only range was incorrectly refused; apply shared production path exclusions to executable discovery. From d7f13f8033edb8f3 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:31:27.419Z).
- Reviewed pinned runtime instrumenter10.0.0; lint and typecheck settings unchanged. From e55a252eb636da43 at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:19:05.183Z).
- Valid build-description writing advisory; no blocking behaviour. From e65e15df8e6ef26c at 0ca63f550fed, by Tal Rotbart (2026-10-26T22:19:09.715Z).
- Enola dependency-traversal heuristic retained as advisory; no measured regression found. From 4e448fe69fa9932a at 173409eacda4, by Tal Rotbart (2026-10-26T22:57:57.606Z).
- Reviewed pinned runtime promotion; versions, resolved URLs, integrity and analyser settings unchanged. Notice dismissed with review reason. From 79ddde5c59f6e8d4 at 173409eacda4, by Tal Rotbart (2026-10-26T22:57:48.578Z).
- Valid plan writing advisory retained. From b6425c2416742e24 at 173409eacda4, by Tal Rotbart (2026-10-26T22:57:53.021Z).
- Reviewed pinned10.0.0 runtime dependency; no linter/typecheck setting changes. Notice dismissed with review reason. From e55a252eb636da43 at 173409eacda4, by Tal Rotbart (2026-10-26T22:57:50.737Z).
- Valid build-description writing advisory retained. From e65e15df8e6ef26c at 173409eacda4, by Tal Rotbart (2026-10-26T22:57:55.385Z).

## Counts

Comparisons: 1. Pending matches: 0.
claude-code: recall 2/13 \(0.154\), precision 2/3 \(0.667\), pending 0.
codex: recall 1/13 \(0.077\), precision 1/1 \(1.000\), pending 0.
melian: recall 10/13 \(0.769\), precision 10/10 \(1.000\), pending 0.
owned-missed: 3.
no-owner: 0.
needs-execution: 0.
out-of-scope: 0.
Valid misses without a reason: 0.

## Differences

At 0ca63f550fed: 0 matched external findings, 4 external-only defects, 5 Melian-only findings.

Matched: 0 external findings, covering 0 Melian findings. External only: 4. Melian only: 5.
External only:
  17644623b20c1dc0  codex  packages/pipeline/src/mutation-enumeration.ts:72  Scrub repository-local Git variables before trusting the install
  2e51f34974a7b604  claude-code  packages/pipeline/src/mutation-enumeration.ts:112-140  JavaScript enumeration loads Babel config files from scratch's ancestors, executing code outside the isolated parser \(including tracked head code\)
  d7f13f8033edb8f3  claude-code  packages/pipeline/src/mutation-enumeration.ts:292-298  Executable test or other non-production files are treated as unsupported production source, so \`mutants list\` refuses test-only changes
  c76785141b518c58  claude-code  scripts/enumerate-mutants.mjs:1-8  scripts/instrument-mutants.mjs is left with no callers
Melian only:
  79ddde5c59f6e8d4  P1 guardrail/policy-change-review  package-lock.json:1
  e55a252eb636da43  P1 guardrail/policy-change-review  packages/pipeline/package.json:1
  b6425c2416742e24  P3 guardrail/forbidden-patterns  docs/design-implementation-plan.md:202
  e65e15df8e6ef26c  P3 guardrail/forbidden-patterns  docs/design-implementation-plan.md:204
  4e448fe69fa9932a  P3 enola/performance  packages/pipeline/src/mutation-enumeration.ts:195

At 173409eacda4: 0 matched external findings, 0 external-only defects, 5 Melian-only findings.

Matched: 0 external findings, covering 0 Melian findings. External only: 0. Melian only: 5.
Melian only:
  b6425c2416742e24  P3 guardrail/forbidden-patterns  docs/design-implementation-plan.md:202
  e65e15df8e6ef26c  P3 guardrail/forbidden-patterns  docs/design-implementation-plan.md:204
  4e448fe69fa9932a  P3 enola/performance  packages/pipeline/src/mutation-enumeration.ts:201
  79ddde5c59f6e8d4  P1 guardrail/policy-change-review  package-lock.json:1  \(dismissed\)
  e55a252eb636da43  P1 guardrail/policy-change-review  packages/pipeline/package.json:1  \(dismissed\)
